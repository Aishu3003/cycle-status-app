// routes/dataRoutes.js
const express = require('express');
const router = express.Router();
const Data = require('../models/Data');

// Import raw sample data
router.post('/import', async (req, res) => {
  try {
    const { timestamp, sample } = req.body;
    const newData = new Data({ timestamp, sample });
    await newData.save(); 
    res.status(201).json({ message: 'Data imported successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
