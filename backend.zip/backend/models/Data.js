// models/Data.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const dataSchema = new Schema({
  timestamp: { type: Date, default: Date.now },
  sample: Number,
});

module.exports = mongoose.model('Data', dataSchema);
